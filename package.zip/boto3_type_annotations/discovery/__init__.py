from boto3_type_annotations.discovery.client import Client
    
__all__ = (
    'Client'
)
