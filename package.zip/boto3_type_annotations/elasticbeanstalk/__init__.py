from boto3_type_annotations.elasticbeanstalk.client import Client
    
__all__ = (
    'Client'
)
