from boto3_type_annotations.glue.client import Client
    
__all__ = (
    'Client'
)
