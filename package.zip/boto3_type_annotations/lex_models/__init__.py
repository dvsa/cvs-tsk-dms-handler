from boto3_type_annotations.lex_models.client import Client
    
__all__ = (
    'Client'
)
