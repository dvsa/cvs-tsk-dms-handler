from boto3_type_annotations.iot1click_devices.client import Client
    
__all__ = (
    'Client'
)
