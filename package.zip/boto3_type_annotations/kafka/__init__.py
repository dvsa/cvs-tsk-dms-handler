from boto3_type_annotations.kafka.client import Client
    
__all__ = (
    'Client'
)
