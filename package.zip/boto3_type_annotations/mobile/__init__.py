from boto3_type_annotations.mobile.client import Client
    
__all__ = (
    'Client'
)
