from boto3_type_annotations.ecs.client import Client
    
__all__ = (
    'Client'
)
