from boto3_type_annotations.license_manager.client import Client
    
__all__ = (
    'Client'
)
