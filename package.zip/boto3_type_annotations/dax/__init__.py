from boto3_type_annotations.dax.client import Client
    
__all__ = (
    'Client'
)
