from boto3_type_annotations.kinesisanalytics.client import Client
    
__all__ = (
    'Client'
)
