from boto3_type_annotations.eks.client import Client
    
__all__ = (
    'Client'
)
