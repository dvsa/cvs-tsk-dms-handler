from boto3_type_annotations.firehose.client import Client
    
__all__ = (
    'Client'
)
