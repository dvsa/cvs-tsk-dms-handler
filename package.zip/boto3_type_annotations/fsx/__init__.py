from boto3_type_annotations.fsx.client import Client
    
__all__ = (
    'Client'
)
