from boto3_type_annotations.comprehend.client import Client
    
__all__ = (
    'Client'
)
