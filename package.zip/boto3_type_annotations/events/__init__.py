from boto3_type_annotations.events.client import Client
    
__all__ = (
    'Client'
)
