from boto3_type_annotations.autoscaling.client import Client
    
__all__ = (
    'Client'
)
