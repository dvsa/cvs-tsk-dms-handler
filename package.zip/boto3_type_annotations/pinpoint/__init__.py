from boto3_type_annotations.pinpoint.client import Client
    
__all__ = (
    'Client'
)
