from boto3_type_annotations.kinesis_video_archived_media.client import Client
    
__all__ = (
    'Client'
)
