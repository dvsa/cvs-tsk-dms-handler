from boto3_type_annotations.organizations.client import Client
    
__all__ = (
    'Client'
)
