from boto3_type_annotations.guardduty.client import Client
    
__all__ = (
    'Client'
)
