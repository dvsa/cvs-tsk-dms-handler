from boto3_type_annotations.cognito_identity.client import Client
    
__all__ = (
    'Client'
)
