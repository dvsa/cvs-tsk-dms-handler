from boto3_type_annotations.elb.client import Client
    
__all__ = (
    'Client'
)
