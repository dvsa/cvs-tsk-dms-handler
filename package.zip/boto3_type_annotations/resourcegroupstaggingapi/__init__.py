from boto3_type_annotations.resourcegroupstaggingapi.client import Client
    
__all__ = (
    'Client'
)
