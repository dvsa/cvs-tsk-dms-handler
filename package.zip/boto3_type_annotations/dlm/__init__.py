from boto3_type_annotations.dlm.client import Client
    
__all__ = (
    'Client'
)
