from boto3_type_annotations.gamelift.client import Client
    
__all__ = (
    'Client'
)
