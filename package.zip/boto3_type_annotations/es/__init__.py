from boto3_type_annotations.es.client import Client
    
__all__ = (
    'Client'
)
