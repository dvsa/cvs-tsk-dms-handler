from boto3_type_annotations.codepipeline.client import Client
    
__all__ = (
    'Client'
)
