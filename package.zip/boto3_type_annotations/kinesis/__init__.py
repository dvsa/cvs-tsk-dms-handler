from boto3_type_annotations.kinesis.client import Client
    
__all__ = (
    'Client'
)
