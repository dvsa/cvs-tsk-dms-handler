from boto3_type_annotations.kinesisanalyticsv2.client import Client
    
__all__ = (
    'Client'
)
