from boto3_type_annotations.acm.client import Client
    
__all__ = (
    'Client'
)
