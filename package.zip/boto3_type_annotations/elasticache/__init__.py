from boto3_type_annotations.elasticache.client import Client
    
__all__ = (
    'Client'
)
