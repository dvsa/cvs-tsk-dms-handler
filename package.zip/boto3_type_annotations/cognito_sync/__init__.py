from boto3_type_annotations.cognito_sync.client import Client
    
__all__ = (
    'Client'
)
