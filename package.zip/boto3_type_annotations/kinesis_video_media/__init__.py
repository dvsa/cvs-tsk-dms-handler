from boto3_type_annotations.kinesis_video_media.client import Client
    
__all__ = (
    'Client'
)
