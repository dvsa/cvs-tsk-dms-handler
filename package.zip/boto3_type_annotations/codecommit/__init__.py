from boto3_type_annotations.codecommit.client import Client
    
__all__ = (
    'Client'
)
