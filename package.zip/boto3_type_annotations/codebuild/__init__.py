from boto3_type_annotations.codebuild.client import Client
    
__all__ = (
    'Client'
)
