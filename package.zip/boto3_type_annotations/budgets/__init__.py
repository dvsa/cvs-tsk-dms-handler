from boto3_type_annotations.budgets.client import Client
    
__all__ = (
    'Client'
)
