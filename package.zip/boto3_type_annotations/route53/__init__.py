from boto3_type_annotations.route53.client import Client
    
__all__ = (
    'Client'
)
